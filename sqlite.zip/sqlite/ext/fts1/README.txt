This folder contains source code to the first full-text search
extension for SQLite.
